var searchData=
[
  ['argtypes_512',['argtypes',['../namespaceMDI__Library_1_1mdi.html#adf6086861f386d0ab85484d36b25fdc4',1,'MDI_Library::mdi']]]
];
