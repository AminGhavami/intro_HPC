var searchData=
[
  ['plugin_5fargc_622',['plugin_argc',['../structplugin__shared__state__struct.html#a3f6368de1a278cfb4f7a46aa4c7d3384',1,'plugin_shared_state_struct']]],
  ['plugin_5fargc_5fptr_623',['plugin_argc_ptr',['../structcode__struct.html#a280e0b5408ad4e489e2d7b39adf220de',1,'code_struct']]],
  ['plugin_5fargv_624',['plugin_argv',['../structplugin__shared__state__struct.html#aaf00ebade76ac8c85d86cc48f9a68b1e',1,'plugin_shared_state_struct']]],
  ['plugin_5fargv_5fallocated_625',['plugin_argv_allocated',['../structplugin__shared__state__struct.html#a2566c68d4287cab3459b7e04b8d9d0f9',1,'plugin_shared_state_struct']]],
  ['plugin_5fargv_5fptr_626',['plugin_argv_ptr',['../structcode__struct.html#a5c759617d8e1eeb69c75883d44f10275',1,'code_struct']]],
  ['plugin_5fhandle_627',['plugin_handle',['../structlibrary__data__struct.html#a11ce13912407d0f389705bc4249bef42',1,'library_data_struct']]],
  ['plugin_5finit_628',['plugin_init',['../structlibrary__data__struct.html#ab6048ef1b522e466ac1a6bd8d63e096b',1,'library_data_struct']]],
  ['plugin_5foptions_629',['plugin_options',['../structplugin__shared__state__struct.html#a6b20b564f03098cb618892500dc58721',1,'plugin_shared_state_struct']]],
  ['plugin_5fpath_630',['plugin_path',['../structcode__struct.html#ab9121b32657cf3175782b87ef50e677d',1,'code_struct']]],
  ['plugin_5funedited_5foptions_631',['plugin_unedited_options',['../structplugin__shared__state__struct.html#acf740d4e3525480aa9b1316c168dd1b6',1,'plugin_shared_state_struct']]],
  ['plugin_5funedited_5foptions_5fptr_632',['plugin_unedited_options_ptr',['../structcode__struct.html#aaf9542a804ffab8d77c53a24db318a79',1,'code_struct']]],
  ['port_633',['port',['../structcode__struct.html#ab72425e4ac4c2d24be4cb49b2c014077',1,'code_struct']]],
  ['py_5flaunch_5fplugin_5fcallback_634',['py_launch_plugin_callback',['../structcode__struct.html#a1df84a740cc2ec981bb6aead1d42ec75',1,'code_struct']]],
  ['python_5finterpreter_5fdict_635',['python_interpreter_dict',['../structplugin__shared__state__struct.html#a523691ac1fb6e365c6fe39f8b4954c3c',1,'plugin_shared_state_struct']]],
  ['python_5finterpreter_5finitialized_636',['python_interpreter_initialized',['../structplugin__shared__state__struct.html#a74a66655bf09338793908bbf49f74afa',1,'plugin_shared_state_struct']]]
];
